﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnergyProducer : MonoBehaviour
{

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void Produce(int sos)
    {

    }

    IEnumerator brenndauer()
    {
        yield return new WaitForSeconds(1f);
    }
}
